﻿string[] words = new String[] {
    "code", "videogame", "dog", "mouse",
    "bottle", "computer", "cat", "internet",
    "nintendo", "university", "pencil", "program",
    "pokemon", "cloud", "video", "music"
};
char[] guesses;
string[] fails;
string secretWord;
bool won, lost;

Random random = new Random();
int index = random.Next(words.Length);
secretWord = words[index];
guesses = new char[secretWord.Length];
Array.Fill(guesses, '*');
fails = new string[0];
won = false;
lost = false;

Console.WriteLine("\n\niBienvenido al juego de ahorcado!\n\n");
GameCicle();

void GameCicle()
{
    Console.WriteLine($"La palabra secreta es { new String(guesses) }");
    PrintHangMan();
    if(lost)
    {
        Console.WriteLine("Peerdiste!");
    }
    else if (won)
    {
        Console.WriteLine("Felicitaciones, Ganaste!");
    }
    else
    {
        PlayerTurn();
    }
}

void PrintHangMan()
{
    Console.Write("Intentos fallidos: ");
    for (int i = 0; i < fails.Length; i++)
    {
        Console.Write(fails[i] + ' ');
    }
    int f = fails.Length;
    Console.WriteLine(" \" ");
    Console.WriteLine("|---");
    Console.WriteLine("|");
    Console.WriteLine($"|       {( f > 0 ? 'o' : ' ')}");
    Console.WriteLine($"|       {(f>2 ? '/' : ' ')}{(f>1 ? '|' : ' ')}{(f>3 ? '\\' : ' ')}");
    Console.WriteLine($"|       {(f>4 ? '/' : ' ')}{(f>5 ? '\\' : ' ')}");
    Console.WriteLine("|");
    Console.WriteLine("/--------\\");
    if (f == 6)
    {
        lost = true;
    }
}

void PlayerTurn()
{
    Console.Write("Ingrese una letra o adivine la palabra: ");
    string attempt = Console.ReadLine() ?? "";
    if (attempt.Length == 0)
    {
        Console.WriteLine("Intente de nuevo");
    }
    else if (attempt.Length == 1)
    {
        TryALetter(attempt[0]);
    }
    else
    {
        TryAWord(attempt);
    }
}


void TryALetter(char letter)
{
    Console.WriteLine("Buscando letra...");
    if (secretWord.Index0f(letter) > -1)
    {
        Console.WriteLine($"La letra {letter} si esta");
        for (int i = 0; i < secretWord.Length; i++)
        {
            if (secretWord[i] == letter)
            {
                guesses[i] = letter;
            }
        }
        won = Array.Index0f(guesses, '*') == -1;
    }
    else
    {
        Console.WriteLine($"La letra {letter} no esta");
        Array.Resize(ref fails, fails.Length + 1);
        fails.SetValue(letter.ToString(), fails.Length - 1);
    }
}

void TryAWord(string word)
{
string words = "hola";
string attempt = "hola";

if (word.CompareTo(attempt) == 0)
    {
        won = true;
    }
}

Console.WriteLine("Game over");
